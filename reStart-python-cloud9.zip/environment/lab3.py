firstString = "water"
secondString = "fall"
thirdString = "wat"+ "sid"
print(thirdString)
