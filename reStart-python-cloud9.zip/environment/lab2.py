# myValue = 6j
# print(myValue)
# print(type(myValue))
myValue=True
print(myValue)
print(type(myValue))
print(myValue + " is of the data type " + str(type(myValue)))


